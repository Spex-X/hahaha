import os
import zipfile
from datetime import datetime

def should_exclude(path):
    exclude_patterns = [
        '__pycache__',
        '.git',
        '.pytest_cache',
        'venv',
        '.env',
        '.venv',
        'node_modules',
        '.DS_Store',
        '*.pyc',
        '*.pyo',
        '*.pyd',
        '.Python',
        '*.so'
    ]
    
    return any(pattern in path for pattern in exclude_patterns)

def create_zip_archive():
    # Get current date for the filename
    current_date = datetime.now().strftime('%Y%m%d')
    zip_filename = f'discourse-pacoin-plugin-{current_date}.zip'
    
    print(f"Creating zip archive: {zip_filename}")
    
    with zipfile.ZipFile(zip_filename, 'w', zipfile.ZIP_DEFLATED) as zipf:
        for root, dirs, files in os.walk('.'):
            # Skip excluded directories
            dirs[:] = [d for d in dirs if not should_exclude(d)]
            
            for file in files:
                file_path = os.path.join(root, file)
                if not should_exclude(file_path) and not file.endswith('.zip'):
                    arcname = os.path.relpath(file_path, '.')
                    print(f"Adding: {arcname}")
                    zipf.write(file_path, arcname)
    
    print(f"\nZip archive created successfully: {zip_filename}")
    print(f"Size: {os.path.getsize(zip_filename) / (1024*1024):.2f} MB")

if __name__ == '__main__':
    create_zip_archive()
