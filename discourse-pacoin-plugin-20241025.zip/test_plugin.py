import unittest
import os
import json
from app import create_app, db

class PACoinPluginTest(unittest.TestCase):
    def setUp(self):
        self.app = create_app()
        self.app.config['TESTING'] = True
        self.app.config['SQLALCHEMY_DATABASE_URI'] = os.environ.get('DATABASE_URL')
        self.client = self.app.test_client()
        self.ctx = self.app.app_context()
        self.ctx.push()
        db.create_all()

    def tearDown(self):
        db.session.remove()
        db.drop_all()
        self.ctx.pop()

    def test_plugin_routes(self):
        """Test that all plugin routes are accessible"""
        routes = [
            '/pacoin/balance',
            '/p2p/marketplace',
            '/packages',
            '/seller/dashboard'
        ]
        for route in routes:
            response = self.client.get(route)
            self.assertIn(response.status_code, [200, 302])  # 200 OK or 302 Redirect to login

    def test_database_models(self):
        """Test that all models can be created and queried"""
        from models import User, Product, Review, Transaction
        
        # Create test user
        user = User(username='test_user', email='test@example.com')
        user.set_password('password123')
        db.session.add(user)
        db.session.commit()
        
        self.assertIsNotNone(user.id)
        self.assertEqual(user.pacoin_balance, 0.0)

    def test_template_rendering(self):
        """Test that all templates can be rendered"""
        templates = [
            'shop/catalog.html',
            'p2p/marketplace.html',
            'loyalty/packages.html',
            'analytics/dashboard.html'
        ]
        with self.app.test_request_context():
            for template in templates:
                try:
                    self.app.jinja_env.get_template(template)
                    rendered = True
                except Exception:
                    rendered = False
                self.assertTrue(rendered, f"Template {template} failed to render")

if __name__ == '__main__':
    unittest.main()
