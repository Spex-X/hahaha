from app import db
from datetime import datetime
from flask_login import UserMixin
from werkzeug.security import generate_password_hash, check_password_hash

class User(UserMixin, db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(64), unique=True, nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)
    password_hash = db.Column(db.String(256))
    pacoin_balance = db.Column(db.Float, default=0.0)
    is_admin = db.Column(db.Boolean, default=False)
    reputation_score = db.Column(db.Float, default=0.0)
    loyalty_points = db.Column(db.Integer, default=0)
    loyalty_tier = db.Column(db.String(20), default='bronze')  # bronze, silver, gold, platinum
    received_reviews = db.relationship('Review', backref='reviewed_user', 
                                     foreign_keys='Review.reviewed_user_id')
    given_reviews = db.relationship('Review', backref='reviewer',
                                  foreign_keys='Review.reviewer_id')
    sent_messages = db.relationship('Message', backref='sender',
                                  foreign_keys='Message.sender_id')
    received_messages = db.relationship('Message', backref='receiver',
                                     foreign_keys='Message.receiver_id')
    package_purchases = db.relationship('PackagePurchase', backref='user')
    
    def set_password(self, password):
        self.password_hash = generate_password_hash(password)
        
    def check_password(self, password):
        return check_password_hash(self.password_hash, password)
    
    def update_loyalty_tier(self):
        if self.loyalty_points >= 1000:
            self.loyalty_tier = 'platinum'
        elif self.loyalty_points >= 500:
            self.loyalty_tier = 'gold'
        elif self.loyalty_points >= 200:
            self.loyalty_tier = 'silver'
        else:
            self.loyalty_tier = 'bronze'

class Product(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    description = db.Column(db.Text)
    price = db.Column(db.Float, nullable=False)
    stock = db.Column(db.Integer, default=0)
    category = db.Column(db.String(50))
    seller_id = db.Column(db.Integer, db.ForeignKey('user.id'))
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    reviews = db.relationship('Review', backref='product')
    is_p2p = db.Column(db.Boolean, default=True)
    status = db.Column(db.String(20), default='available')  # available, sold, reserved

class PromotionalPackage(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    description = db.Column(db.Text)
    price = db.Column(db.Float, nullable=False)
    pacoin_amount = db.Column(db.Float, nullable=False)  # Amount of PACoins included
    bonus_percentage = db.Column(db.Float, default=0)  # Bonus percentage
    loyalty_points = db.Column(db.Integer, default=0)  # Points earned from package
    min_loyalty_tier = db.Column(db.String(20), default='bronze')  # Minimum tier required
    is_active = db.Column(db.Boolean, default=True)
    valid_until = db.Column(db.DateTime)
    purchases = db.relationship('PackagePurchase', backref='package')

class PackagePurchase(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    package_id = db.Column(db.Integer, db.ForeignKey('promotional_package.id'), nullable=False)
    purchase_date = db.Column(db.DateTime, default=datetime.utcnow)
    amount_paid = db.Column(db.Float, nullable=False)
    pacoins_received = db.Column(db.Float, nullable=False)
    loyalty_points_earned = db.Column(db.Integer, nullable=False)

class Message(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    sender_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    receiver_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    product_id = db.Column(db.Integer, db.ForeignKey('product.id'))
    content = db.Column(db.Text, nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    is_read = db.Column(db.Boolean, default=False)

class Review(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    reviewer_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    reviewed_user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    product_id = db.Column(db.Integer, db.ForeignKey('product.id'), nullable=False)
    rating = db.Column(db.Integer, nullable=False)  # 1-5 stars
    comment = db.Column(db.Text)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    media_attachments = db.relationship('MediaAttachment', backref='review')
    helpful_votes = db.Column(db.Integer, default=0)
    verified_purchase = db.Column(db.Boolean, default=False)

class MediaAttachment(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    review_id = db.Column(db.Integer, db.ForeignKey('review.id'), nullable=False)
    media_type = db.Column(db.String(10), nullable=False)  # 'photo' or 'video'
    file_path = db.Column(db.String(255), nullable=False)
    thumbnail_path = db.Column(db.String(255))
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

class Auction(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    product_id = db.Column(db.Integer, db.ForeignKey('product.id'))
    seller_id = db.Column(db.Integer, db.ForeignKey('user.id'))
    start_price = db.Column(db.Float, nullable=False)
    current_price = db.Column(db.Float, nullable=False)
    end_time = db.Column(db.DateTime, nullable=False)
    is_active = db.Column(db.Boolean, default=True)
    winner_id = db.Column(db.Integer, db.ForeignKey('user.id'))

class Transaction(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    sender_id = db.Column(db.Integer, db.ForeignKey('user.id'))
    receiver_id = db.Column(db.Integer, db.ForeignKey('user.id'))
    amount = db.Column(db.Float, nullable=False)
    transaction_type = db.Column(db.String(20))  # 'transfer', 'purchase', 'auction', 'package'
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    loyalty_points_earned = db.Column(db.Integer, default=0)
    
class Cart(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'))
    product_id = db.Column(db.Integer, db.ForeignKey('product.id'))
    quantity = db.Column(db.Integer, default=1)
