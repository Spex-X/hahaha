# PACoin Discourse Plugin Installation Guide

## Overview
PACoin is a comprehensive Discourse plugin that adds an integrated shop, P2P marketplace, and auction system using a virtual currency called PACoins. The plugin includes features like user reviews, loyalty programs, and advanced seller analytics.

## Prerequisites
- Discourse instance version 2.7.0 or higher
- PostgreSQL database
- Ruby 2.7.0 or higher
- Redis server

## Installation Steps

### 1. Add Plugin to Discourse
Add the plugin to your Discourse installation by editing `app.yml` and adding under `hooks`:

```yaml
hooks:
  after_code:
    - exec:
        cd: $home/plugins
        cmd:
          - git clone https://github.com/discourse/discourse-pacoin.git
```

### 2. Configure Environment Variables
Add the following to your `app.yml` in the `env` section:

```yaml
env:
  DISCOURSE_PACOIN_ENABLED: true
  DISCOURSE_PACOIN_INITIAL_BALANCE: "100"
  DISCOURSE_PACOIN_DAILY_REWARD: "10"
```

### 3. Database Configuration
The plugin will automatically create its tables during the first migration. Run:

```bash
cd /var/discourse
./launcher rebuild app
```

### 4. Enable the Plugin
1. Visit your admin panel at `your-discourse-url.com/admin/plugins`
2. Find "PACoin" in the plugins list
3. Click "Enable"
4. Rebuild your Discourse instance

### 5. Configure Plugin Settings
In the admin panel, go to Settings > Plugin > PACoin and configure:
- Initial PACoin balance for new users
- Daily PACoin reward amount
- Transaction fees (if any)
- Loyalty program tiers

## Plugin Components

### Core Features
- Virtual currency (PACoin) system
- User-to-user transactions
- Reputation and review system
- P2P marketplace with chat
- Auction system
- Loyalty program
- Seller analytics dashboard

### File Structure
```
discourse-pacoin/
├── assets/
│   ├── javascripts/
│   │   └── discourse/
│   │       ├── components/
│   │       └── templates/
│   └── stylesheets/
├── config/
│   ├── locales/
│   └── settings.yml
├── db/
│   └── migrate/
└── plugin.rb
```

## Usage Instructions

### For Users
1. Earn PACoins through:
   - Daily login rewards
   - Forum participation
   - Receiving helpful votes on posts
   - Completing transactions

2. Use PACoins for:
   - Purchasing items in the marketplace
   - Participating in auctions
   - Sending tips to other users

### For Sellers
1. List items in the marketplace
2. Create auctions
3. Access analytics dashboard
4. Manage customer reviews
5. Track loyalty program metrics

## Troubleshooting

### Common Issues
1. **Plugin Not Appearing**: Ensure the plugin is properly cloned and the instance is rebuilt.
2. **Database Migrations**: Run `rake pacoin:migrate` if tables are missing.
3. **Asset Compilation**: Clear cache with `rake assets:clean` and rebuild.

### Support
For technical support:
1. Visit the [GitHub Issues](https://github.com/discourse/discourse-pacoin/issues) page
2. Join the Discourse Meta discussion
3. Contact the plugin maintainers

## Updates and Maintenance
1. To update the plugin:
```bash
cd /var/discourse/plugins/discourse-pacoin
git pull origin master
cd /var/discourse
./launcher rebuild app
```

2. Backup recommendations:
   - Regular database backups
   - Export of PACoin transaction logs
   - Backup of plugin settings

## Security Considerations
1. All PACoin transactions are logged and traceable
2. User balances are protected against tampering
3. Review system includes anti-fraud measures
4. Chat messages are encrypted
5. File uploads are scanned and validated

## License
This plugin is released under the MIT License. See the LICENSE file for details.
