import os
import logging
from flask import Flask
from flask_sqlalchemy import SQLAlchemy
from flask_socketio import SocketIO
from flask_login import LoginManager
from sqlalchemy.orm import DeclarativeBase

# Set up logging
logging.basicConfig(level=logging.DEBUG)
logger = logging.getLogger(__name__)

class Base(DeclarativeBase):
    pass

db = SQLAlchemy(model_class=Base)
socketio = SocketIO()
login_manager = LoginManager()

@login_manager.user_loader
def load_user(id):
    from models import User
    return User.query.get(int(id))

def create_app():
    app = Flask(__name__)
    
    # Configuration
    app.config['SECRET_KEY'] = os.environ.get("FLASK_SECRET_KEY", "your-secret-key")
    app.config['SQLALCHEMY_DATABASE_URI'] = os.environ.get("DATABASE_URL")
    app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
    app.config['SQLALCHEMY_ENGINE_OPTIONS'] = {
        "pool_recycle": 300,
        "pool_pre_ping": True,
    }
    app.config['MAX_CONTENT_LENGTH'] = 10 * 1024 * 1024  # 10MB max file size

    logger.info("Database URL: %s", app.config['SQLALCHEMY_DATABASE_URI'])
    
    try:
        # Initialize extensions
        db.init_app(app)
        socketio.init_app(app)
        login_manager.init_app(app)
        login_manager.login_view = 'auth.login'

        with app.app_context():
            # Import routes
            from routes import shop, auction, pacoin, auth, review, p2p, loyalty, analytics
            
            # Register blueprints
            app.register_blueprint(shop.bp)
            app.register_blueprint(auction.bp)
            app.register_blueprint(pacoin.bp)
            app.register_blueprint(auth.bp)
            app.register_blueprint(review.bp)
            app.register_blueprint(p2p.bp)
            app.register_blueprint(loyalty.bp)
            app.register_blueprint(analytics.bp)
            
            # Create database tables
            db.create_all()
            
            # Create test data
            create_test_data()
            
        return app
    except Exception as e:
        logger.error("Error creating app: %s", str(e), exc_info=True)
        raise

def create_test_data():
    try:
        from models import User, Product, PromotionalPackage
        from datetime import datetime, timedelta
        
        # Only create test data if no users exist
        if User.query.first() is None:
            logger.info("Creating test data...")
            # Create test user
            test_user = User(
                username='testuser',
                email='test@example.com',
                pacoin_balance=1000.0,
                reputation_score=4.5,
                loyalty_points=150
            )
            test_user.set_password('password123')
            
            # Create test seller
            test_seller = User(
                username='seller',
                email='seller@example.com',
                pacoin_balance=5000.0,
                reputation_score=4.8,
                loyalty_points=600
            )
            test_seller.set_password('password123')
            
            # Create test admin
            admin_user = User(
                username='admin',
                email='admin@example.com',
                pacoin_balance=10000.0,
                is_admin=True,
                loyalty_points=1200
            )
            admin_user.set_password('admin123')
            
            # Create promotional packages
            basic_package = PromotionalPackage(
                name='Basic Package',
                description='Start your journey with PACoins',
                price=10.0,
                pacoin_amount=1000,
                bonus_percentage=0,
                loyalty_points=100,
                min_loyalty_tier='bronze',
                is_active=True,
                valid_until=datetime.utcnow() + timedelta(days=30)
            )
            
            silver_package = PromotionalPackage(
                name='Silver Package',
                description='More PACoins and bonus rewards',
                price=25.0,
                pacoin_amount=3000,
                bonus_percentage=5,
                loyalty_points=250,
                min_loyalty_tier='silver',
                is_active=True,
                valid_until=datetime.utcnow() + timedelta(days=30)
            )
            
            gold_package = PromotionalPackage(
                name='Gold Package',
                description='Premium package with maximum benefits',
                price=50.0,
                pacoin_amount=7000,
                bonus_percentage=10,
                loyalty_points=500,
                min_loyalty_tier='gold',
                is_active=True,
                valid_until=datetime.utcnow() + timedelta(days=30)
            )
            
            db.session.add(test_user)
            db.session.add(test_seller)
            db.session.add(admin_user)
            db.session.add(basic_package)
            db.session.add(silver_package)
            db.session.add(gold_package)
            db.session.commit()
            logger.info("Test data created successfully")
    except Exception as e:
        logger.error("Error creating test data: %s", str(e), exc_info=True)
        raise

if __name__ == '__main__':
    try:
        app = create_app()
        socketio.run(app, host='0.0.0.0', port=5000, debug=True)
    except Exception as e:
        logger.error("Error running app: %s", str(e), exc_info=True)
