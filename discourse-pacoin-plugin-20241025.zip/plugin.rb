# name: discourse-pacoin
# about: PACoin plugin with integrated shop and auction system
# version: 0.1.0
# authors: Replit Team
# url: https://github.com/discourse/discourse-pacoin

enabled_site_setting :pacoin_enabled
register_asset 'stylesheets/pacoin.scss'
register_asset 'stylesheets/seller-analytics.scss'

after_initialize do
  module ::DiscoursePACoin
    class Engine < ::Rails::Engine
      engine_name "discourse_pacoin"
      isolate_namespace DiscoursePACoin
    end
  end

  require_dependency 'application_controller'
  
  class DiscoursePACoin::AnalyticsController < ::ApplicationController
    requires_plugin 'discourse-pacoin'
    before_action :ensure_logged_in
    before_action :ensure_staff
    
    def seller_stats
      user = User.find(params[:user_id])
      
      # Calculate analytics data
      stats = {
        total_revenue: calculate_total_revenue(user),
        products_sold: count_products_sold(user),
        average_rating: calculate_average_rating(user),
        active_products: count_active_products(user),
        sales_trend: generate_sales_trend(user),
        rating_distribution: generate_rating_distribution(user),
        top_products: get_top_products(user),
        repeat_customers: get_repeat_customers(user)
      }
      
      render_json_dump(stats)
    end
    
    private
    
    def calculate_total_revenue(user)
      PACoinTransaction.where(receiver: user)
                      .where(transaction_type: 'purchase')
                      .sum(:amount)
    end
    
    def count_products_sold(user)
      PACoinTransaction.where(receiver: user)
                      .where(transaction_type: 'purchase')
                      .count
    end
    
    def calculate_average_rating(user)
      Review.where(reviewed: user).average(:rating) || 0
    end
    
    def count_active_products(user)
      PACoinP2PListing.where(seller: user, status: 'available').count
    end
    
    def generate_sales_trend(user)
      PACoinTransaction.where(receiver: user)
                      .where(transaction_type: 'purchase')
                      .where('created_at >= ?', 30.days.ago)
                      .group('DATE(created_at)')
                      .order('DATE(created_at)')
                      .pluck('DATE(created_at) as date', 'SUM(amount) as amount')
                      .map { |date, amount| { date: date, amount: amount } }
    end
    
    def generate_rating_distribution(user)
      Review.where(reviewed: user)
            .group(:rating)
            .order(:rating)
            .count
            .map { |rating, count| { rating: rating, count: count } }
    end
    
    def get_top_products(user)
      PACoinP2PListing.where(seller: user)
                      .joins(:transactions)
                      .group('pacoin_p2p_listings.id')
                      .order('COUNT(pacoin_transactions.id) DESC')
                      .limit(5)
                      .pluck(
                        'pacoin_p2p_listings.title',
                        'COUNT(pacoin_transactions.id)',
                        'SUM(pacoin_transactions.amount)'
                      )
                      .map { |name, count, revenue| 
                        { name: name, sales_count: count, revenue: revenue } 
                      }
    end
    
    def get_repeat_customers(user)
      PACoinTransaction.where(receiver: user)
                      .where(transaction_type: 'purchase')
                      .group(:sender_id)
                      .having('COUNT(*) > 1')
                      .order('COUNT(*) DESC')
                      .limit(5)
                      .joins(:sender)
                      .pluck(
                        'users.username',
                        'COUNT(*)',
                        'SUM(pacoin_transactions.amount)'
                      )
                      .map { |username, count, total| 
                        { username: username, purchase_count: count, total_spent: total }
                      }
    end
  end

  DiscoursePACoin::Engine.routes.draw do
    get '/analytics/seller' => 'analytics#seller_stats'
  end
  
  Discourse::Application.routes.append do
    mount ::DiscoursePACoin::Engine, at: '/pacoin'
  end
end
