import os
import subprocess

def run_git_command(command):
    try:
        subprocess.run(command, shell=True, check=True)
        return True
    except subprocess.CalledProcessError as e:
        print(f"Error executing command: {command}")
        print(f"Error: {str(e)}")
        return False

# Configure Git
run_git_command('git config --global user.name "Replit"')
run_git_command('git config --global user.email "replit@example.com"')

# Add all files
run_git_command('git add .')

# Commit changes
run_git_command('git commit -m "Update: PACoin Discourse plugin configuration and features"')

# Add remote using GITHUB_TOKEN
github_token = os.environ.get('GITHUB_TOKEN')
if not github_token:
    print("Error: GITHUB_TOKEN not found in environment variables")
    exit(1)

# Remove existing origin if it exists
run_git_command('git remote remove origin 2>/dev/null || true')

# Add new remote with updated repository name
run_git_command(f'git remote add origin https://{github_token}@github.com/replit/discourse-pacoin-plugin.git')

# Push to GitHub with force and set upstream
run_git_command('git push -u origin main --force')
print("Repository has been pushed to GitHub successfully")
